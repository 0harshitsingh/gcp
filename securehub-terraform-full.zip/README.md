# SecureHub Terraform - Minimal Architecture (Hub + Spoke)

This repo deploys:
- Hub VPC + Subnet
- Spoke VPC + Subnet
- Cloud Router + NAT
- VPC Peering
- Test VMs
- GitHub Actions (Plan)
- Cloud Build (Apply)
